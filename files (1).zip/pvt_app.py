"""
PVT Black Oil / Wet Gas Application
Computes PVT properties using industry-standard correlations
and exports ECLIPSE-format tables (PVTO, PVDG, PVTG, PVTW).
"""

import streamlit as st
import numpy as np
import pandas as pd
from correlations import (OilCorrelations, GasCorrelations,
                          WaterCorrelations, WetGasCorrelations)
from eclipse_export import (build_pvto, build_pvdg, build_pvtg,
                            build_pvtw, build_pvtw_from_table,
                            build_density, build_full_deck)

st.set_page_config(page_title="PVT Tool", layout="wide")
st.title("PVT Properties & ECLIPSE Export")
st.caption("Black oil, dry gas, wet gas / condensate, and brine — with PVTO/PVDG/PVTG/PVTW export.")

# -----------------------------
# Sidebar
# -----------------------------
with st.sidebar:
    st.header("Fluid & Reservoir Inputs")

    fluid = st.selectbox("Fluid type",
                         ["Oil (Black Oil)", "Dry Gas", "Wet Gas / Condensate", "Water"])

    st.subheader("Reservoir Conditions")
    T_res = st.number_input("Reservoir temperature (°F)", value=200.0, min_value=60.0, max_value=400.0)
    P_res = st.number_input("Reservoir pressure (psia)", value=3500.0, min_value=14.7, max_value=15000.0)

    st.subheader("Pressure Range for Tables")
    P_min = st.number_input("P min (psia)", value=14.7, min_value=14.7)
    P_max = st.number_input("P max (psia)", value=6000.0, min_value=100.0)
    n_points = st.slider("Number of pressure points", 5, 40, 15)

    st.subheader("Include Brine in Export?")
    include_water = st.checkbox("Add PVTW alongside oil/gas tables", value=True)

# -----------------------------
# Inputs & compute
# -----------------------------
col_in, col_out = st.columns([1, 2])
pressures = np.linspace(P_min, P_max, n_points)


# =====================================================
# OIL
# =====================================================
if fluid == "Oil (Black Oil)":
    with col_in:
        st.subheader("Oil Properties")
        api = st.number_input("Oil API gravity", value=35.0, min_value=10.0, max_value=60.0)
        gas_sg = st.number_input("Gas specific gravity (air=1)", value=0.75, min_value=0.55, max_value=1.5)
        Rsi = st.number_input("Solution GOR at Pb (scf/STB)", value=600.0, min_value=0.0)
        Pb_input = st.number_input("Bubble point pressure (psia, 0=calc)", value=0.0, min_value=0.0)

        st.markdown("**Correlations**")
        rs_corr = st.selectbox("Rs / Pb", ["Standing", "Vasquez-Beggs", "Glaso", "Lasater"])
        bo_corr = st.selectbox("Bo", ["Standing", "Vasquez-Beggs", "Glaso"])
        mu_corr = st.selectbox("Dead-oil viscosity", ["Beggs-Robinson", "Beal", "Glaso"])

    oil = OilCorrelations(api=api, gas_sg=gas_sg, T=T_res,
                          rs_corr=rs_corr, bo_corr=bo_corr, mu_corr=mu_corr)
    Pb = Pb_input if Pb_input > 0 else oil.bubble_point(Rsi)

    rows = []
    for P in pressures:
        if P <= Pb:
            Rs = oil.solution_gor(P)
            Bo = oil.formation_volume_factor(P, Rs, saturated=True)
            mu = oil.viscosity(P, Rs, Pb, saturated=True)
        else:
            Rs = Rsi
            Bo = oil.formation_volume_factor(P, Rsi, saturated=False, Pb=Pb)
            mu = oil.viscosity(P, Rsi, Pb, saturated=False)
        rows.append({"P (psia)": P, "Rs (scf/STB)": Rs, "Bo (rb/STB)": Bo, "μo (cp)": mu})
    df = pd.DataFrame(rows)

    with col_out:
        st.subheader(f"Computed Properties — Pb = {Pb:,.1f} psia")
        st.dataframe(df.style.format({"P (psia)": "{:.1f}", "Rs (scf/STB)": "{:.2f}",
                                       "Bo (rb/STB)": "{:.4f}", "μo (cp)": "{:.4f}"}),
                     use_container_width=True, height=380)
        c1, c2, c3 = st.columns(3)
        c1.line_chart(df.set_index("P (psia)")["Rs (scf/STB)"])
        c2.line_chart(df.set_index("P (psia)")["Bo (rb/STB)"])
        c3.line_chart(df.set_index("P (psia)")["μo (cp)"])

    st.divider()
    st.subheader("ECLIPSE Export")
    pvto_text = build_pvto(df, Pb, oil, Rsi, P_max)
    density_text = build_density(api=api, gas_sg=gas_sg)

    pvtw_text = ""
    if include_water:
        st.markdown("**Brine for PVTW**")
        salinity = st.number_input("Salinity (ppm NaCl-eq)", value=30000.0, min_value=0.0,
                                    key="oil_sal")
        bw_corr = st.selectbox("Water correlation", ["McCain", "Meehan", "Numbere", "Spivey"],
                                key="oil_wcorr")
        water = WaterCorrelations(salinity_ppm=salinity, T=T_res, corr=bw_corr)
        pvtw_text = build_pvtw_from_table(pressures, water, P_res)

    st.code(pvto_text + ("\n" + pvtw_text if pvtw_text else ""), language="text")
    deck = build_full_deck(pvto=pvto_text, pvtw=pvtw_text, density=density_text)
    st.download_button("Download full PVT deck (.INC)", deck,
                       file_name="PVT_BLACKOIL.INC", mime="text/plain")


# =====================================================
# DRY GAS
# =====================================================
elif fluid == "Dry Gas":
    with col_in:
        st.subheader("Gas Properties")
        gas_sg = st.number_input("Gas specific gravity (air=1)", value=0.70, min_value=0.55, max_value=1.5)
        N2 = st.number_input("N2 mol fraction", value=0.0, min_value=0.0, max_value=0.3)
        CO2 = st.number_input("CO2 mol fraction", value=0.0, min_value=0.0, max_value=0.5)
        H2S = st.number_input("H2S mol fraction", value=0.0, min_value=0.0, max_value=0.3)

        st.markdown("**Correlations**")
        z_corr = st.selectbox("Z-factor", ["Hall-Yarborough", "Dranchuk-Abou-Kassem"])
        mug_corr = st.selectbox("Gas viscosity", ["Lee-Gonzalez-Eakin", "Carr-Kobayashi-Burrows"])

    gas = GasCorrelations(gas_sg=gas_sg, T=T_res, N2=N2, CO2=CO2, H2S=H2S,
                          z_corr=z_corr, mu_corr=mug_corr)

    rows = []
    for P in pressures:
        if P < 14.7: continue
        Z = gas.z_factor(P)
        rows.append({"P (psia)": P, "Z": Z,
                     "Bg (rb/scf)": gas.formation_volume_factor(P, Z),
                     "μg (cp)": gas.viscosity(P, Z)})
    df = pd.DataFrame(rows)

    with col_out:
        st.subheader("Computed Gas Properties")
        st.dataframe(df.style.format({"P (psia)": "{:.1f}", "Z": "{:.4f}",
                                       "Bg (rb/scf)": "{:.6f}", "μg (cp)": "{:.5f}"}),
                     use_container_width=True, height=380)
        c1, c2, c3 = st.columns(3)
        c1.line_chart(df.set_index("P (psia)")["Z"])
        c2.line_chart(df.set_index("P (psia)")["Bg (rb/scf)"])
        c3.line_chart(df.set_index("P (psia)")["μg (cp)"])

    st.divider()
    st.subheader("ECLIPSE Export")
    pvdg_text = build_pvdg(df)
    density_text = build_density(api=35.0, gas_sg=gas_sg)
    pvtw_text = ""
    if include_water:
        salinity = st.number_input("Salinity (ppm NaCl-eq)", value=30000.0, key="gas_sal")
        bw_corr = st.selectbox("Water correlation", ["McCain", "Meehan", "Numbere", "Spivey"],
                                key="gas_wcorr")
        water = WaterCorrelations(salinity_ppm=salinity, T=T_res, corr=bw_corr)
        pvtw_text = build_pvtw_from_table(pressures, water, P_res)

    st.code(pvdg_text + ("\n" + pvtw_text if pvtw_text else ""), language="text")
    deck = build_full_deck(pvdg=pvdg_text, pvtw=pvtw_text, density=density_text)
    st.download_button("Download full PVT deck (.INC)", deck,
                       file_name="PVT_DRYGAS.INC", mime="text/plain")


# =====================================================
# WET GAS / CONDENSATE
# =====================================================
elif fluid == "Wet Gas / Condensate":
    with col_in:
        st.subheader("Wet Gas Properties")
        gas_sg = st.number_input("Separator gas SG (air=1)", value=0.72, min_value=0.55, max_value=1.5)
        api_cond = st.number_input("Condensate API", value=55.0, min_value=40.0, max_value=80.0)
        cgr = st.number_input("CGR (STB/MMscf)", value=80.0, min_value=1.0, max_value=300.0)
        Pdew = st.number_input("Dew point pressure (psia)", value=4500.0, min_value=500.0)
        N2 = st.number_input("N2 mol fraction", value=0.0, min_value=0.0, max_value=0.3, key="wg_n2")
        CO2 = st.number_input("CO2 mol fraction", value=0.0, min_value=0.0, max_value=0.5, key="wg_co2")
        H2S = st.number_input("H2S mol fraction", value=0.0, min_value=0.0, max_value=0.3, key="wg_h2s")

        st.markdown("**Correlations**")
        z_corr = st.selectbox("Z-factor", ["Hall-Yarborough", "Dranchuk-Abou-Kassem"], key="wg_z")
        mug_corr = st.selectbox("Gas viscosity", ["Lee-Gonzalez-Eakin", "Carr-Kobayashi-Burrows"], key="wg_mu")
        rv_corr = st.selectbox("Rv vs P model", ["Linear-Pdew", "Constant"])

    wet = WetGasCorrelations(gas_sg=gas_sg, api_cond=api_cond, cgr_stb_per_mmscf=cgr,
                              T=T_res, N2=N2, CO2=CO2, H2S=H2S,
                              z_corr=z_corr, mu_corr=mug_corr,
                              rv_corr=rv_corr, Pdew=Pdew)

    rows = []
    for P in pressures:
        if P < 14.7: continue
        Z = wet.z_factor(P)
        rows.append({"P (psia)": P, "Z": Z,
                     "Bg (rb/Mscf)": wet.formation_volume_factor(P, Z) * 1000.0,
                     "Rv (STB/Mscf)": wet.rv(P) * 1000.0,
                     "μg (cp)": wet.viscosity(P, Z)})
    df = pd.DataFrame(rows)

    with col_out:
        st.subheader(f"Wet Gas Properties — recombined SG = {wet.gamma_g_res:.3f}")
        st.dataframe(df.style.format({"P (psia)": "{:.1f}", "Z": "{:.4f}",
                                       "Bg (rb/Mscf)": "{:.5f}", "Rv (STB/Mscf)": "{:.4f}",
                                       "μg (cp)": "{:.5f}"}),
                     use_container_width=True, height=380)
        c1, c2 = st.columns(2)
        c1.line_chart(df.set_index("P (psia)")[["Bg (rb/Mscf)", "Rv (STB/Mscf)"]])
        c2.line_chart(df.set_index("P (psia)")[["Z", "μg (cp)"]])

    st.divider()
    st.subheader("ECLIPSE Export — PVTG")
    pvtg_text = build_pvtg(pressures, wet)
    density_text = build_density(api=api_cond, gas_sg=gas_sg)

    pvtw_text = ""
    if include_water:
        salinity = st.number_input("Salinity (ppm NaCl-eq)", value=30000.0, key="wg_sal")
        bw_corr = st.selectbox("Water correlation", ["McCain", "Meehan", "Numbere", "Spivey"],
                                key="wg_wcorr")
        water = WaterCorrelations(salinity_ppm=salinity, T=T_res, corr=bw_corr)
        pvtw_text = build_pvtw_from_table(pressures, water, P_res)

    st.code(pvtg_text + ("\n" + pvtw_text if pvtw_text else ""), language="text")
    deck = build_full_deck(pvtg=pvtg_text, pvtw=pvtw_text, density=density_text)
    st.download_button("Download full PVT deck (.INC)", deck,
                       file_name="PVT_WETGAS.INC", mime="text/plain")


# =====================================================
# WATER (standalone)
# =====================================================
else:
    with col_in:
        st.subheader("Water / Brine")
        salinity = st.number_input("Salinity (ppm NaCl-eq)", value=30000.0, min_value=0.0)
        bw_corr = st.selectbox("Correlation", ["McCain", "Meehan", "Numbere", "Spivey"])
        include_gas = st.checkbox("Include dissolved-gas effect (Rsw)", value=False)
        Pb_water = 0.0
        if include_gas:
            Pb_water = st.number_input("Bubble-point for gas-saturated water (psia)",
                                        value=P_res, min_value=14.7)

    water = WaterCorrelations(salinity_ppm=salinity, T=T_res, corr=bw_corr,
                              include_gas=include_gas, Pb=Pb_water)

    rows = []
    for P in pressures:
        rows.append({
            "P (psia)": P,
            "Bw (rb/STB)": water.bw(P),
            "Cw (1/psi)": water.compressibility(P),
            "μw (cp)": water.viscosity(P),
            "Rsw (scf/STB)": water.rsw(P) if include_gas else 0.0,
            "ρw (lb/ft³)": water.density(P),
        })
    df = pd.DataFrame(rows)

    with col_out:
        st.subheader("Computed Water Properties")
        st.dataframe(df.style.format({"P (psia)": "{:.1f}", "Bw (rb/STB)": "{:.4f}",
                                       "Cw (1/psi)": "{:.3e}", "μw (cp)": "{:.4f}",
                                       "Rsw (scf/STB)": "{:.2f}", "ρw (lb/ft³)": "{:.3f}"}),
                     use_container_width=True, height=380)
        c1, c2, c3 = st.columns(3)
        c1.line_chart(df.set_index("P (psia)")["Bw (rb/STB)"])
        c2.line_chart(df.set_index("P (psia)")["Cw (1/psi)"])
        c3.line_chart(df.set_index("P (psia)")["μw (cp)"])

    st.divider()
    st.subheader("ECLIPSE Export — PVTW")
    pvtw_text = build_pvtw_from_table(pressures, water, P_res)
    st.code(pvtw_text, language="text")
    deck = build_full_deck(pvtw=pvtw_text)
    st.download_button("Download PVTW include (.INC)", deck,
                       file_name="PVTW.INC", mime="text/plain")


st.divider()
with st.expander("About the correlations"):
    st.markdown("""
**Oil:** Standing, Vasquez-Beggs, Glaso, Lasater (Rs/Pb/Bo);
Beggs-Robinson, Beal, Glaso (μ).

**Gas:** Sutton pseudo-criticals + Wichert-Aziz sour-gas correction.
Z by Hall-Yarborough or Dranchuk-Abou-Kassem. Viscosity by Lee-Gonzalez-Eakin
or Carr-Kobayashi-Burrows.

**Wet gas / condensate:** McCain recombination of separator gas + condensate
into a reservoir-fluid SG, then standard Z-factor methods. Rv either constant
(very lean gas) or linearly retreating below the dew point.

**Water:**
- *McCain* — industry standard, valid for typical reservoir T,P,salinity.
- *Meehan* — older, simple, gas-free Bw.
- *Numbere* — McCain-style with refined salinity volume term.
- *Spivey-Valko-McCain (2004)* — density-based, more accurate over wide T,P.
- Optional dissolved-gas swelling via Rsw (McCain) and Dodson-Standing Cw correction.
""")
