# PVT Black Oil / Wet Gas Streamlit App

## Run
```
pip install -r requirements.txt
streamlit run pvt_app.py
```

## Fluids supported
- **Black oil** -> PVTO
- **Dry gas** -> PVDG
- **Wet gas / condensate** -> PVTG (saturated + Rv branch)
- **Water (brine)** -> PVTW (auto-fitted from a P,T table)

## Correlations

### Oil
- Rs / Pb: Standing, Vasquez-Beggs, Glaso, Lasater
- Bo: Standing, Vasquez-Beggs, Glaso
- Viscosity: Beggs-Robinson, Beal, Glaso (dead oil) + Beggs-Robinson live oil + Vasquez-Beggs under-saturated

### Gas (dry & wet)
- Pseudo-criticals: Sutton + Wichert-Aziz (sour-gas correction for CO2/H2S)
- Z-factor: Hall-Yarborough or Dranchuk-Abou-Kassem
- Viscosity: Lee-Gonzalez-Eakin or Carr-Kobayashi-Burrows

### Wet gas
- Reservoir-fluid SG via McCain recombination of separator gas + condensate
- Rv vs P: constant (very lean) or linear-retreating below dew point

### Water
- McCain (industry standard, gas-free or with dissolved gas)
- Meehan (older, simple)
- Numbere (McCain-style with refined salinity term)
- Spivey-Valko-McCain (2004) (density-based, wider P,T validity)
- Optional dissolved-gas effect: Rsw via McCain, Cw via Dodson-Standing
- Outputs Bw, Cw, viscosity, density, Rsw

## ECLIPSE export notes
All output is in FIELD units (psia, °F, scf/STB, rb/STB, rb/Mscf, cP, lb/ft3).
- **PVTO**: under-saturated branch attached only to the highest Rs node
- **PVDG**: standard P, Bg, μg dry-gas table
- **PVTG**: outer P loop, inner Rv branch with monotonically decreasing Rv
- **PVTW**: single-line, but with Cw and viscosibility back-fitted from the
  water correlation evaluated at the user's pressure range, so the linear PVTW
  model matches the correlation as closely as possible
- **DENSITY**: surface oil/water/gas densities
